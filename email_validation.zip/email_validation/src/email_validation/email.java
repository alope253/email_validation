package email_validation;

import java.io.IOException;
import java.util.Scanner;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class email {
	public static void main(String[] args)  {
		
		
		emailsuspects emailsuspects = new emailsuspects(20);
		
		emailsuspects.addSuspect("pat@hotmail.com");
		emailsuspects.addSuspect("Sally@yahoo.com");
		emailsuspects.addSuspect("Peter@gmail.com");
		emailsuspects.addSuspect("Bobby@outlook.com");
		emailsuspects.addSuspect("Rudolph@hotmail.com");
		emailsuspects.addSuspect("Bobness@yahoo.com");
		emailsuspects.addSuspect("Ubiiga@yahoo.com");
		emailsuspects.addSuspect("Tony@outlook.com");
		emailsuspects.addSuspect("Rudolph@hotmail.com");
		emailsuspects.addSuspect("Aaron@gmail.com");
		emailsuspects.addSuspect("Yolo@yahoo.com");
		emailsuspects.addSuspect("Yaka@outlook.com");
		emailsuspects.addSuspect("Big@yahoo.com");
		emailsuspects.addSuspect("Doug@gmail.com");
		
		
		System.out.println("Search for name:");
		Scanner scanner = new Scanner(System.in);
		String searchFor = scanner.nextLine();
		
		boolean foundMatch = emailsuspects.foundMatch(searchFor);
		if (foundMatch) {
			System.out.println(searchFor + " is indeed an email suspect");
		} else {
			System.out.println(searchFor + " is not an email suspect");
		}
		
	}

}